<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>Beside you</title>
</head>
<body>


<!--削除・編集が可能なサブファイル-->


<?php

// DB設定を記述したファイルを読み込む
include 'config/env.php';

// ユーザー定義関数を記述したファイルを読み込む
include 'main/function.php';

// 共通プログラムを記述したファイルを読み込む
include 'main/common.php';

?>

<!--フォームをチェックするファイルを読み込む-->
<script src="js/function.js"></script>

<!--ボタンを装飾するファイルを読み込む-->
<link rel="stylesheet" href="css/button.css">

<!--フォームを装飾するファイルを読み込む-->
<link rel="stylesheet" href="css/form.css">

<!--ページ全体を装飾するファイルを読み込む-->
<link rel="stylesheet" href="css/page.css">

<hr>
【編集フォーム】
<hr>

        <!-- 編集フォーム -->
                                    <!--ファイルデータを扱う設定-->
    <form action="index.php" method="post" name="edit_post"
    enctype="multipart/form-data" onsubmit="return leak_check('edit_post', 'user_name', 'comment', 'password');
    return confirm_edit()">                 <!--空欄をチェック後、確認ポップアップ-->

        <input class="form-text" type="text" name="user_name" placeholder="名前"
        value="<?php echo isset($edit_name) ? $edit_name : ''; ?>"><br>

        <!--改行可能のコメント欄を作成する-->
        <textarea class="area-text" name="comment" placeholder="コメント" cols="30" rows="3">
        <?php echo isset($edit_comment) ? $edit_comment : ''; ?></textarea><br>

        <!--パスワード / [maxlength] ⇒ パスワードの桁数を制限-->
        <input class="form-text" type="password" maxlength="4" name="password"
        placeholder="パスワード(数字4桁)" pattern="[0-9]*" title="数字4桁"
        value="<?php echo isset($edit_pass) ? $edit_pass : ''; ?>"><br><br>

        <!--画像をアップロードする-->
        <input type="file" name="image" placeholder="画像を選択">

        <!--送信ボタンを作成する-->
        <input class="edit-button" type="submit" name="submit" value="編集">

        <!-- 編集機能で投稿フォームへデータを表示した際に、隠し表示で編集番号を呼び出す(これを用いて、新規投稿か編集投稿か判別する)-->
        <input type="hidden" name="edit_number"
        value="<?php echo isset($edit_ID) ? $edit_ID : ''; ?>">
        <br>
    </form>

<hr>
【削除フォーム】
<hr>

        <!-- 削除フォーム -->
    <form action="index.php" method="post" name="delete_post"
    onsubmit="return leak_check('delete_post', 'delete', 'password');
    return confirm_delete()">   <!--空欄をチェック後、確認ポップアップ-->

        <input class="form-number" type="number" min="1" name="delete" placeholder="番号"
        value="<?php echo isset($edit_name) ? $edit_name : ''; ?>">

        <!--パスワード / [maxlength] ⇒ パスワードの桁数を制限-->
        <input class="form-text" type="password" maxlength="4" name="password"
        placeholder="パスワード(数字4桁)" pattern="[0-9]*" title="数字4桁">
        <input class="delete-button" type="submit" name="submit" value="削除">
    </form>

<hr>
【投稿一覧】
<hr>

<?php

// 投稿の表示について記述したファイルを読み込む
include 'main/display.php';

?>

</body>
</html>