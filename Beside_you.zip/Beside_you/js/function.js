
    /*ユーザー定義関数をまとめたファイル*/

// 編集・削除の確認
    function confirm_edit(){
        return confirm("投稿を差し替えます。よろしいですか？") // 確認ダイアログを表示
    }
    function confirm_delete() {
        return confirm("投稿を削除します。よろしいですか？");
    }

// フォームの入力漏れを検知 (引数は足りてなくても問題ないように組む)
    function leak_check(post_name, form1, form2, form3) {
        var flag = 0;

        // 必須項目の入力チェック (フォーム総称.フォーム名)
        if (document.forms[post_name][form1].value === "") { // 「名前」の入力をチェック
            flag = 1;
        } else if (document.forms[post_name][form2].value === "") { // 「コメント」の入力をチェック
            flag = 1;
        } else if (document.forms[post_name][form3].value === "") { // 「パスワード」の入力をチェック
            flag = 1;
        }

        if (flag) {
            window.alert('入力漏れがあります'); // 入力漏れがあれば警告ダイアログを表示
            return false; // 送信を中止
        } else {
            return true; // 送信を実行
        }
    }