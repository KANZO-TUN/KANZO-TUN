<?php

    /*データベース内容を投稿として表示するファイル*/

// 投稿時間を基準に、降順で表示
$sql = 'SELECT * FROM KANZO_TABLE ORDER BY time DESC';
$result = $pdo->query($sql);
$results = $result->fetchAll();
foreach ($results as $row){
   // $rowの中にはテーブルのカラム名が入る
    echo $row['id'].' / ';
    echo $row['name'].' / ';
    echo $row['time'];

    // いいね表示 (favoriteが設定されているときのみ表示)
    if(!($row['favorite'] == 0)){
        echo " / 💖".$row['favorite'];
    }

    echo "<br>".nl2br($row['comment'])."<br>"; // nl2br関数でEnterを識別する
    $imageURL = $row["image_path"];
    echo "<img src='$imageURL' alt='アップロードされた画像'><hr>";
}

// ロギングの終了
Logging_stop();


?>