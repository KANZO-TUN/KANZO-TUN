<?php

    /*ユーザー定義関数をまとめたファイル*/

// 1.ロギング

// ロギング初期設定
$filename = "log/Logging.txt"; // indexから見た相対パス
$fp = fopen($filename,"a");
$br = PHP_EOL;
$hr = "---------------------------------------------------";

// 実行ごとにタイトルと日付を記録する関数を設定
// 0-1.ロギングスタート関数
function Logging_start($log_title){
    global $fp, $br, $hr; // グローバル変数の呼び出し
    fwrite($fp,$hr.$br.$log_title.$br
    .date("Y/m/d H:i:s").$br.$hr.$br);
}

// データベースの実行結果を記録する関数を設定
// 0-2.ロギング関数
function Logging($result,$log){
    if($result){
        global $fp, $br; // グローバル変数の呼び出し
        fwrite($fp,"[".$log."]に成功しました".$br);
    }else{
        global $fp, $br;
        fwrite($fp,"[".$log."]に失敗しました".$br);
    }
}

// 実行の終了を記録する関数を設定
// 0-3.ロギングストップ関数
function Logging_stop(){
    global $fp, $br; // グローバル変数の呼び出し
    fwrite($fp,"【終了】".$br);
    fclose($fp); // fcloseは一度しか設定できないのでここで。
}


// 2.テーブル操作


// [テスト用]テーブルを削除する関数を設定
function DROP_TABLE($pdo){
    $sql = 'DROP TABLE KANZO_TABLE';
    $result = $pdo->query($sql);

    $log = "テーブルの削除";
    Logging($result,$log);
}

// [テスト用]テーブルを作成する関数を設定
function CREATE_TABLE($pdo){
    $sql = "CREATE TABLE IF NOT EXISTS KANZO_TABLE"
    ."("
    // カラム名 データ型 (オプション/MAX文字数) で指定
    . "id INT AUTO_INCREMENT PRIMARY KEY,"
    . "name CHAR(32),"
    . "time DATETIME,"
    . "comment TEXT,"
    . "password CHAR(32)"
    . "image_path CHAR(255)"
    . "favorite INT"
    .");";
    
    $log = "テーブルの作成";
    $result = $pdo->query($sql);
    Logging($result,$log);
}
function SHOW_TABLE($pdo){
    $sql = 'SHOW CREATE TABLE KANZO_TABLE';
    $result = $pdo -> query($sql);
    foreach ($result as $row){
        echo $row[1]."<br>"; 
    }
    $log = "テーブルの確認";
    Logging($result,$log);
}

// [テスト用]
// DROP_TABLE($pdo);
// CREATE_TABLE($pdo);
// SHOW_TABLE($pdo);

/*
$sql = 'ALTER TABLE KANZO_TABLE CHANGE pass password VARCHAR(32)';
$pdo->exec($sql); */

?>