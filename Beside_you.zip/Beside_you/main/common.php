<?php


    /*共通するプログラムが記述された基本ファイル*/


    // 投稿用プログラム(index)
    if(!empty($_POST["user_name"]) && !empty($_POST["comment"])
                                    // ※[edit_number = null] で新規投稿を判別
    && !empty($_POST["password"]) && empty($_POST["edit_number"])
    ){

        // ロギングの開始(タイトル設定)
        $log_title = "投稿";
        Logging_start($log_title);
        $result = false; // ロギング変数を宣言
        
        // (新規投稿の場合、パスワードを変数に保存する)
        // 「投稿番号(id)/名前(name)/コメント(comment)/投稿日時(time)/パスワード(password)」の順で掲載
        $sql = $pdo -> prepare("INSERT INTO KANZO_TABLE (name,comment,time,password,image_path,favorite)
            VALUES (:name,:comment,:time,:password,:image_path,:favorite)");

        // 受信した変数をデータベース変数に代入
        $name = $_POST["user_name"];
        $time = date("Y/m/d H:i:s");
        $comment = $_POST["comment"];
        $password = $_POST["password"];
        $favorite = 0; // おそらくデフォルト値として0を設定する

        // 画像ファイルの取り扱い方を指定する
        $target_dir = './image/'; // アップロードされたファイルを保存するフォルダ
        $image_name = basename($_FILES["image"]["name"]); // アップロードされたファイルの元の名称
        $target_file = $target_dir . $image_name; // アップロードされたファイルのフルパス
        $image_fileType = pathinfo($target_file,PATHINFO_EXTENSION); // 拡張子
        
        // 画像ファイルのパスをデータベース変数に代入
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            $image_path = $target_file;
            $result = true;
        }else{
            $result = false;
        }

        // ロギング設定
        $log = "画像のアップロード";
        Logging($result,$log);

        // プレースホルダーに値をバインド
        $sql -> bindParam(':name',$name,PDO::PARAM_STR);
        $sql -> bindParam(':time',$time,PDO::PARAM_STR);
        $sql -> bindParam(':comment',$comment,PDO::PARAM_STR);
        $sql -> bindParam(':password',$password,PDO::PARAM_STR);
        $sql -> bindParam(':image_path',$image_path,PDO::PARAM_STR);
        $sql->bindParam(':favorite', $favorite, PDO::PARAM_INT);

        // INSERT文を実行
        $result = $sql -> execute();

        // ロギング設定
        $log = "データの入力";
        Logging($result,$log);
    }
    
    // 削除用プログラム(sub.phpから受信したデータを処理)
    if(!empty($_POST["delete"]) && (!empty($_POST["password"]))){

        // ロギングの開始(タイトル設定)
        $log_title = "削除";
        Logging_start($log_title);
        $result = false; // ロギング変数を宣言

        // 指定した行のパスワードを取得
        $id = $_POST["delete"];
        $sql = 'SELECT password FROM KANZO_TABLE WHERE id = :id';
        $stmt = $pdo->prepare($sql); // WHERE句を用いる場合、prepareが必須
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $result = $stmt->execute();
        $true_pass = $stmt->fetchColumn();

        // ロギング設定
        $log = "本来のパスワードの取得";
        Logging($result,$log);
        
        // データを削除 (取得したパスワードと受信したパスワードが正しい場合)
        if($true_pass === $_POST["password"]){ // [===] ... データ型まで比較できる厳密演算子
            $sql = 'DELETE from KANZO_TABLE WHERE id=:id';
            $stmt = $pdo->prepare($sql); // WHERE句を用いる場合、prepareが必須
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $result = $stmt->execute();

            // ロギング設定
            $log = "データの削除";
            Logging($result,$log);

                // レコード削除後、にid番号を再設定する (ブラウザ表示されるためロギング不要)
            $sql = 'SET @id = 0';
            $pdo->exec($sql); // idの初期化

            $sql = 'UPDATE KANZO_TABLE SET id = (@id := @id + 1)'; 
            $pdo->exec($sql); // idを連番に振りなおす

            $sql = 'ALTER TABLE KANZO_TABLE AUTO_INCREMENT = 1';
            $pdo->exec($sql); // idの自動増分値を１にリセット

        }else{ // 例外処理とロギング
            $result = false;
            $log = "データの削除";
            Logging($result,$log);
            echo $log."に失敗しました<br>パスワードが違います";
        }
    }
    
    // 編集用プログラム (index ⇒ sub)
    if(!empty($_POST["edit"]) && (!empty($_POST["password"]))){

        // ロギングの開始(タイトル設定)
        $log_title = "編集(受信)";
        Logging_start($log_title);
        $result = false; // ロギング変数を宣言

        // 指定した行のパスワードを取得
        $id = $_POST["edit"];
        $sql = 'SELECT password FROM KANZO_TABLE WHERE id = :id';
        $stmt = $pdo->prepare($sql); // WHERE句を用いる場合、prepareが必須
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $result = $stmt->execute();
        $true_pass = $stmt->fetchColumn();

        // ロギング設定
        $log = "本来のパスワードの取得";
        Logging($result,$log);

        // 編集したいデータを受信 (取得したパスワードと受信したパスワードが正しい場合)
        if($true_pass === $_POST["password"]){ // [===] ... データ型まで比較できる厳密演算子
            // 指定した行のデータを抽出し、配列に格納
            $sql = 'SELECT * FROM KANZO_TABLE WHERE id = :id';
            $stmt = $pdo->prepare($sql); // WHERE句を用いる場合、prepareが必須
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $result = $stmt->execute();
            $results = $stmt->fetchAll();

            // ロギング設定 (ブラウザ上にも表示されるが、重要動作のため)
            $log = "編集データの受信";
            Logging($result,$log);

            foreach ($results as $row){
                //フォーム(HTML)の変数に代入する (配列の要素はテーブルのカラム名で指定する)
                $edit_name = $row['name'];
                $edit_comment = $row['comment'];
                $edit_pass = $row['password'];
                $edit_ID = $id; // フォーム出力時のために別変数へ代入
            }

        }else{ // 例外処理とロギング
            $result = false;
            $log = "編集データの受信";
            Logging($result,$log);
            echo $log."に失敗しました<br>パスワードが違います
            <br>前のページへ戻り、正しいパスワードを入力してください";
        }
    }

    // 編集用プログラム (sub ⇒ index , DB に反映)        ※edit_numberで編集投稿を判別
    if(!empty($_POST["comment"]) && !empty($_POST["user_name"])
    && !empty($_POST["password"])&& !empty($_POST["edit_number"])){

        // ロギングの開始(タイトル設定)
        $log_title = "編集(送信)";
        Logging_start($log_title);
        $result = false; // ロギング変数を宣言

        // 既存のファイルパスを取得し、編集前の画像を削除
        $sql = 'SELECT image_path FROM KANZO_TABLE WHERE id = :id';
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':id',$id,PDO::PARAM_INT);
        $stmt->execute();
        $existing_target_file = $stmt->fetchColumn();

        if ($existing_target_file && file_exists($existingFilePath)) {
            // 既存のファイルが存在する場合、削除する
            if (unlink($existingFilePath)) {
                $result = true;
            } else {
                $result = false;
            }
        }

        // ロギング設定
        $log = "編集前画像の削除";
        Logging($result,$log);

        // 「投稿番号(id)/名前(name)/コメント(comment)/投稿日時(time)/パスワード(password)」の順で編集
        $id = $_POST["edit_number"];
        $sql = $pdo -> prepare('UPDATE KANZO_TABLE SET name=:name,comment=:comment,
        time=:time,password=:password,image_path=:image_path,favorite=:favorite WHERE id=:id');

        // 受信した変数をデータベース変数に代入
        $name = $_POST["user_name"]."(編集済み)";
        $time = date("Y/m/d H:i:s");
        $comment = $_POST["comment"];
        $password = $_POST["password"];

        // いいね数をリセット
        $favorite = 0;

        // 画像ファイルの取り扱い方を指定する
        $target_dir = './image/'; // アップロードされたファイルを保存するフォルダ
        $image_name = basename($_FILES["image"]["name"]); // アップロードされたファイルの元の名称
        $target_file = $target_dir . $image_name; // アップロードされたファイルのフルパス
        $image_fileType = pathinfo($target_file,PATHINFO_EXTENSION); // 拡張子
        
        // 画像ファイルのパスをデータベース変数に代入
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            $image_path = $target_file;
            $result = true;
        }else{
            $result = false;
        }

        // ロギング設定
        $log = "画像の再アップロード";
        Logging($result,$log);

        // プレースホルダーに値をバインド
        $sql -> bindParam(':name', $name, PDO::PARAM_STR);
        $sql -> bindParam(':comment', $comment, PDO::PARAM_STR);
        $sql -> bindParam(':time', $time, PDO::PARAM_STR);
        $sql -> bindParam(':password', $password, PDO::PARAM_STR);
        $sql -> bindParam(':image_path', $image_path, PDO::PARAM_STR);
        $sql -> bindParam(':favorite', $favorite, PDO::PARAM_INT); // いいね数をリセット
        $sql -> bindParam(':id', $id, PDO::PARAM_INT); // UPDATEのため、idもバインド

        // UPDATE文を実行
        $result = $sql -> execute();

        // ロギング設定
        $log = "編集データの送信";
        Logging($result,$log);
    }

    // いいね用プログラム
    if (!empty($_POST["favorite"])) {
        // ロギングの開始(タイトル設定)
        $log_title = "いいね";
        Logging_start($log_title);
        $result = false; // ロギング変数を宣言

        $id = $_POST["favorite"];
        $favorite = 1; // 増分値[1]を指定

        $sql = $pdo->prepare('UPDATE KANZO_TABLE SET favorite=favorite+:favorite WHERE id = :id');

        // プレースホルダーに値をバインド
        $sql -> bindParam(':favorite', $favorite, PDO::PARAM_INT);
        $sql -> bindParam(':id', $id, PDO::PARAM_INT); // UPDATEのため、idもバインド

        // UPDATE文を実行
        $result = $sql->execute();

        // ロギング設定
        $log = "データの加算";
        Logging($result, $log);
    }

?>