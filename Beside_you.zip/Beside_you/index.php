<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>Beside you</title>
</head>
<body>


<!--投稿・閲覧が可能なメインファイル-->


<?php

// DB設定を記述したファイルを読み込む
include 'config/env.php';

// ユーザー定義関数を記述したファイルを読み込む
include 'main/function.php';

// 共通プログラムを記述したファイルを読み込む
include 'main/common.php';

?>

<!--フォームをチェックするファイルを読み込む-->
<script src="js/function.js"></script>

<!--ボタンを装飾するファイルを読み込む-->
<link rel="stylesheet" href="css/button.css">

<!--フォームを装飾するファイルを読み込む-->
<link rel="stylesheet" href="css/form.css">

<!--ページ全体を装飾するファイルを読み込む-->
<link rel="stylesheet" href="css/page.css">

<hr>
【入力フォーム】~あなたの日常を共有しましょう！~
<hr>
        <!-- 投稿フォーム -->
                                    <!--ファイルデータを扱う設定-->
    <form action="" method="post" enctype="multipart/form-data" 
    name="new_post" onsubmit="return leak_check('new_post', 'user_name', 'comment', 'password')"> 
                        <!--空欄をチェック-->
        お名前<br>
        <input class="form-text" type="text" name="user_name"><br>

        <!--改行可能のコメント欄を作成する-->
        コメント<br>
        <textarea class="area-text" name="comment"></textarea><br>

        <!--パスワード / [maxlength] ⇒ パスワードの桁数を制限-->
        パスワード(数字４桁)<br>
        <input class="form-text" type="password" maxlength="4" name="password"
        pattern="[0-9]*" title="数字4桁"><br><br>

        <!--画像をアップロードする-->
        <label for="file_upload">👉画像を選択👈
        <input class="form-upload" type="file" name="image" id="file_upload"></label>

        <!--送信ボタンを作成する-->
        <input class="post-button" type="submit" name="submit">

    </form>

<hr>
【編集・削除フォーム】~過去の投稿を管理したい方はこちらへ~
<hr>
    
        <!-- 編集フォーム -->
    <form action="sub.php" method="post" name="edit_post"
    onsubmit="return leak_check('edit_post', 'edit', 'password')">
                        <!--空欄をチェック-->
        番号<br>
        <input class="form-number" type="number" min="1" name="edit"><br>

        <!--パスワード / [maxlength] ⇒ パスワードの桁数を制限-->
        パスワード(数字４桁)<br>
        <input class="form-text" type="password" maxlength="4" name="password"
        pattern="[0-9]*" title="数字4桁">
        <input class="edit-button" type="submit" name="submit" value="編集">
    </form>

        <!-- 削除フォーム --><br>
    <form action="sub.php" method="post" name="delete">
        <input class="delete-button delete-margin" type="submit" name="submit" value="削除">
    </form>

<hr>
【いいねフォーム】~大切な人の日常にいいねをしよう！~
<hr>

        <!-- いいねフォーム-->
    <form action="" method="post" name="favorite_post"
    onsubmit="return leak_check('favorite_post', 'favorite')">
                        <!--空欄をチェック-->
        番号<br>
        <input class="form-number" type="number" min="1" name="favorite">
        <input class ="favorite-button" type="submit" name="submit" value="いいね">

<hr>
【投稿一覧】
<hr>

<?php

// 投稿の表示について記述したファイルを読み込む
include 'main/display.php';

?>

</body>
</html>