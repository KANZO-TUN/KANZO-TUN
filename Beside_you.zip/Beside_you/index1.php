<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>Beside you</title>
</head>
<body>


<!--このファイルは投稿・閲覧が可能なメインファイル-->


<?php

// DB設定を記述したファイルを読み込む
include 'config/env.php';

// ユーザー定義関数を記述したファイルを読み込む
include 'main/function.php';

// 共通プログラムを記述したファイルを読み込む
include 'main/common.php';

?>

<hr>
【入力フォーム】~あなたの日常を共有しましょう！~
<hr>
        <!-- 投稿フォーム ＆ 編集機能 (投稿フォームへ編集前データが送られる) -->
                                    <!--ファイルデータを扱う設定-->
    <form action="" method="post" enctype="multipart/form-data"> 
        <input type="text" name="user_name" placeholder="名前"><br>

        <!--改行可能のコメント欄を作成する-->
        <textarea name="comment" placeholder="コメント" ></textarea><br>

        <!--パスワード / [tel & maxlength] ⇒ パスワードの桁数を制限-->
        <input type="tel" maxlength="4" name="password" placeholder="パスワード(半角4桁)"><br><br>

        <!--画像をアップロードする-->
        <input type="file" name="image" placeholder="画像を選択">

        <!--送信ボタンを作成する-->
        <input type="submit" name="submit">

    </form>

<hr>
【編集・削除フォーム】~過去の投稿を管理したい方はこちらへ~
<hr>
    
        <!-- 編集フォーム -->
    <form action="index2.php" method="post">
        <input type="number" min="1" name="edit" placeholder="編集対象番号">

        <!--パスワード / [tel & maxlength] ⇒ パスワードの桁数を制限-->
        <input type="tel" maxlength="4" name="password" placeholder="パスワード(半角4桁)">
        <input type="submit" name="submit" value="編集">
    </form>

        <!-- 削除フォーム -->
    <form action="index2.php" method="post">
        <input type="submit" name="submit" value="削除">
    </form>

<hr>
【投稿フォーム】
<hr>

    <?php

        // 投稿時間を基準に、降順で表示
        $sql = 'SELECT * FROM KANZO_TABLE ORDER BY time DESC';
        $result = $pdo->query($sql);
        $results = $result->fetchAll();
        foreach ($results as $row){
           // $rowの中にはテーブルのカラム名が入る
            echo $row['id'].' / ';
            echo $row['name'].' / ';
            echo $row['time']."<br>";
            echo nl2br($row['comment'])."<br>"; // nl2br関数でEnterを識別する
            $imageURL = $row["image_path"];
            echo "<img src='$imageURL' alt='アップロードされた画像'><hr>";
        }

        // ロギングの終了
        Logging_stop();
    ?>
</body>
</html>