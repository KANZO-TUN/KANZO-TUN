<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>Beside you</title>
</head>
<body>


<!--このファイルは削除・編集が可能なサブファイル-->


<?php

// DB設定を記述したファイルを読み込む
include 'config/env.php';

// ユーザー定義関数を記述したファイルを読み込む
include 'main/function.php';

// 共通プログラムを記述したファイルを読み込む
include 'main/common.php';

?>

<hr>
【編集フォーム】
<hr>

        <!-- 編集フォーム -->
                                    <!--ファイルデータを扱う設定-->
    <form action="index1.php" method="post"
    enctype="multipart/form-data" onsubmit="return confirm_edit()"> 
        <input type="text" name="user_name" placeholder="名前"
        value="<?php echo isset($edit_name) ? $edit_name : ''; ?>"><br>

        <!--改行可能のコメント欄を作成する-->
        <textarea name="comment" placeholder="コメント" 
        cols="30" rows="3">
        <?php echo isset($edit_comment) ? $edit_comment : ''; ?></textarea><br>

        <!--パスワード / [tel & maxlength] ⇒ パスワードの桁数を制限-->
        <input type="tel" maxlength="4" name="password" placeholder="パスワード(半角4桁)"
        value="<?php echo isset($edit_pass) ? $edit_pass : ''; ?>"><br><br>

        <!--画像をアップロードする-->
        <input type="file" name="image" placeholder="画像を選択">

        <!--送信ボタンを作成する-->
        <input type="submit" name="submit">

        <!-- 編集機能で投稿フォームへデータを表示した際に、隠し表示で編集番号を呼び出す(これを用いて、新規投稿か編集投稿か判別する)-->
        <input type="hidden" name="edit_number"
        value="<?php echo isset($edit_ID) ? $edit_ID : ''; ?>">
        <br>
    </form>

<hr>
【削除フォーム】
<hr>

        <!-- 削除フォーム -->
    <form action="index1.php" method="post" onsubmit="return confirm_delete()">
        <input type="number" min="1" name="delete" placeholder="削除対象番号"
        value="<?php echo isset($edit_name) ? $edit_name : ''; ?>">

        <!--パスワード / [tel & maxlength] ⇒ パスワードの桁数を制限-->
        <input type="tel" maxlength="4" name="password" placeholder="パスワード(半角4桁)">
        <input type="submit" name="submit" value="削除">
    </form>

    <!--あとでJavaScriptに切り出し-->
    <script>
    function confirm_edit(){
        return confirm("投稿を差し替えます。よろしいですか？")
    }
    function confirm_delete() {
        return confirm("投稿を削除します。よろしいですか？");
    }

    </script>

<hr>
【投稿フォーム】
<hr>

<?php

// 投稿時間を基準に、降順で表示
$sql = 'SELECT * FROM KANZO_TABLE ORDER BY time DESC';
$result = $pdo->query($sql);
$results = $result->fetchAll();
foreach ($results as $row){
   // $rowの中にはテーブルのカラム名が入る
    echo $row['id'].' / ';
    echo $row['name'].' / ';
    echo $row['time']."<br>";
    echo nl2br($row['comment'])."<br>"; // nl2br関数でEnterを識別する
    $imageURL = $row["image_path"];
    echo "<img src='$imageURL' alt='アップロードされた画像'><hr>";
}

// ロギングの終了
Logging_stop();
?>

</body>
</html>