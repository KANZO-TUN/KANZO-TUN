<?php


    /*このファイルはDB設定を記述した設定ファイル*/

// DB接続設定
$dsn = 'XXX';
$user = 'XXX';
$password = 'XXX';
// DBエラー検出設定
$pdo = new PDO($dsn, $user, $password, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING));


?>