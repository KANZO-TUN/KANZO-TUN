class Box{ // クラスの作成 -> 座標・色彩・画像IDなど
    constructor(ctx, xy, wh, rgb, img_id=null, img_array=null){
        this.ctx = ctx
        this.x = xy[0]
        this.y = xy[1]
        this.wh = wh
        this.r = rgb[0]
        this.g = rgb[1]
        this.b = rgb[2]
	this.img_id = img_id
	this.img_array = img_array
    }

    set_color(){ // 色彩の設定
        this.ctx.fillStyle = "rgb("+this.r+","+this.g+","+this.b+")"
    }

    draw(){ // 画像IDの設定 (+例外処理)
        if(this.img_id == null){
            this.set_color()
            this.ctx.fillRect(this.x*this.wh, this.y*this.wh, this.wh, this.wh)
        }else{
	    this.ctx.drawImage(this.img_array[this.img_id], this.x*this.wh, this.y*this.wh)
        }
    }

    atari(box){ // オブジェクト同士の接触を感知するメソッド
        if(this.x == box.x && this.y == box.y){
            return true // 戻り値[true]
        }
        return false // 戻り値[false]
    }
}

class Pacman extends Box{ // BoxクラスにPacmanクラスを継承 (キー操作について)
    static RIGHT = 0
    static DOWN = 1
    static LEFT = 2
    static UP = 3
    
    move(dir){ // パックマンをキー操作すで移動させるメソッド
        this.img_id = dir
        if(dir == Pacman.RIGHT){
            this.x += 1
        }else if(dir == Pacman.LEFT){
            this.x -= 1
        }else if(dir == Pacman.DOWN){
            this.y += 1
        }else if(dir == Pacman.UP){
            this.y -= 1
	}
    }
}

// 定数宣言
const BOX_WH = 50
const BOX_N = 9
const WH = BOX_WH*BOX_N
const LEFT = 37
const RIGHT = 39
const UP = 38
const DOWN = 40

// getElementById = 現在表示されているHTMLドキュメントのIDを取得する
// getContext = HTMLのcanvas要素を[2d]で取得する
let g_ctx = document.getElementById("c01").getContext("2d")

// 壁の生成 (配列 ⇒ for文で簡易生成 ⇒ 座標指定で詳細生成)
let g_kabe_xyid = []
let count = 0;
for (let x = 1; x <= 7; x += 2) { // for文にて交互に作成
    for (let y = 1; y <= 7; y += 2) {
        if (count % 2 === 0) { // countで偶数と奇数を識別
            img_id = 0;
        }
        else {
            img_id = 1;
        }
        g_kabe_xyid.push([x, y, img_id]);
        count++; // countをインクリメント
    }
}
                        // jsからのパスではなく、読み込むHTMLファイルからのパス
let g_kabe_img_file = ["js/element/kabe0.png", "js/element/kabe1.png"]
let g_kabe_img = []

 // エサの生成 (王冠の生成 ⇒ 座標指定で詳細生成 ⇒ for文で簡易生成)
g_esa_xyid = [[4, 4, 1], [0, 7, 0], [0, 6, 0], [1, 6, 0], [2, 6, 0], [2, 5, 0], [2, 4, 0], [3, 4, 0]]

// 上１列
for (let x =1; x <= 8; x +=1) {
    y = 0;
    img_id = 0;
    g_esa_xyid.push([x, y, img_id]);
}

// 右１行
for (let y =1; y <= 8; y +=1) {
    x = 8;
    img_id = 0;
    g_esa_xyid.push([x, y, img_id]);
}

// 下１列
for (let x =0; x <= 7; x +=1) {
    y = 8;
    img_id = 0;
    g_esa_xyid.push([x, y, img_id]);
}
                // jsからのパスではなく、読み込むHTMLファイルからのパス
g_esa_img_file = ["js/element/esa0.png", "js/element/esa1.png"]
g_esa_img = []

                        // jsからのパスではなく、読み込むHTMLファイルからのパス
let g_pacman_img_file = ["js/element/pacman0.png", "js/element/pacman1.png", "js/element/pacman2.png", "js/element/pacman3.png"]
let g_pacman_img = []

// 背景は未設定に。
let g_background = null

// 要素自体の配列宣言
let g_kabe = []
let g_esa = []
let g_pacman = null // 同時多発的に発生しないので、null値を挿入

onkeydown = keydown

// 要素を生成する関数の実行
make_background()
make_kabe()
make_esa()
make_pacman()
setInterval(draw, 100) // [draw]関数をイベントトリブン設定に。

function draw(){ // 要素を描画する関数の設定
    g_background.draw()
    draw_kabe()
    draw_esa()
    g_pacman.draw()
}

function keydown(e){ // カーソル押下時の関数
    // 矢印キーのキーコードを取得
    const arrowKeys = [LEFT, UP, RIGHT, DOWN];

    // 矢印キーの場合はデフォルトのスクロールをキャンセル (ポートフォリオ用に設定)
    if (arrowKeys.includes(e.keyCode)) {
        e.preventDefault();
    }
    
    let xy = [g_pacman.x, g_pacman.y]
    if(e.keyCode == RIGHT){
        if(g_pacman.x < BOX_N-1){
            g_pacman.move(Pacman.RIGHT)
        }
    }else if(e.keyCode == LEFT){
        if(g_pacman.x > 0){
            g_pacman.move(Pacman.LEFT)
        }
    }else if(e.keyCode == DOWN){
        if(g_pacman.y < BOX_N-1){
            g_pacman.move(Pacman.DOWN)
        }
    }else if(e.keyCode == UP){
        if(g_pacman.y > 0){
            g_pacman.move(Pacman.UP)
        }
    }

    // パックマンとエサが重なった場合、[atari]関数を呼び出し、捕食
    for(let i = 0; i < g_esa.length; i += 1){
        if(g_esa[i].atari(g_pacman)){
            g_esa[i].x = -1
            break 
        }
    }

    // パックマンと壁が重なった場合、[atari]関数を呼び出し、通行不能に。(元座標に戻す)
    for(let i = 0; i < g_kabe.length; i += 1){
        if(g_kabe[i].atari(g_pacman)){
            g_pacman.x = xy[0]
            g_pacman.y = xy[1]
            break
        }
    }
}

function make_background(){ //　背景の設定
    g_background = new Box(g_ctx, [0, 0], WH, [0, 0, 0])
}

function make_kabe(){ // 壁の生成の設定
    for(let i = 0; i < g_kabe_img_file.length; i += 1){
        let img = new Image()
        img.src = g_kabe_img_file[i]
        g_kabe_img.push(img)
    }
    for(let i = 0; i < g_kabe_xyid.length; i += 1){
        let xy = g_kabe_xyid[i].slice(0, 2)
	let id = g_kabe_xyid[i][2]
        g_kabe.push(new Box(g_ctx, xy, BOX_WH, [128, 128, 128], id, g_kabe_img))
    }
}

function make_esa(){ // エサの生成の設定
    for(let i = 0; i < g_esa_img_file.length; i += 1){
        let img = new Image()
        img.src = g_esa_img_file[i]
        g_esa_img.push(img)
    }
    for(let i = 0; i < g_esa_xyid.length; i += 1){
        let xy = g_esa_xyid[i].slice(0, 2)
	let id = g_esa_xyid[i][2]
        g_esa.push(new Box(g_ctx, xy, BOX_WH, [128, 128, 128], id, g_esa_img))
    }
}

function make_pacman(){ // パックマンの生成の設定
    for(let i = 0; i < g_pacman_img_file.length; i += 1){
        let img = new Image()
        img.src = g_pacman_img_file[i]
        g_pacman_img.push(img)
    }
    g_pacman = new Pacman(g_ctx, [0, 0], BOX_WH, [0, 255, 0], 0, g_pacman_img)    
}

function draw_kabe(){ // 壁の描画の設定
    for(let i = 0; i < g_kabe.length; i += 1){
        g_kabe[i].draw()
    }
}

function draw_esa(){ //エサの描画の設定
    for(let i = 0; i < g_esa.length; i += 1){
        g_esa[i].draw()
    }
}